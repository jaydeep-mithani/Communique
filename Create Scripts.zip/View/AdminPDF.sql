USE [Communique]
GO

/****** Object:  View [dbo].[pdfData]    Script Date: 02/20/20 10:25:05 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE VIEW [dbo].[pdfData] AS
SELECT studentExtend.Technology, Faculty.FacultyFirstname,
 Faculty.FacultyLastname, studentExtend.StudentProjectname,
 studentExtend.DU, studentExtend.Reason, studentExtend.Agree
 FROM studentExtend, Faculty
 WHERE studentExtend.Technology LIKE Faculty.FacultyTechleader
GO

