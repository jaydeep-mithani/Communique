USE [Communique]
GO

/****** Object:  Table [dbo].[Technology]    Script Date: 02/20/20 10:24:18 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Technology](
	[TechnologyID] [numeric](20, 0) IDENTITY(1,1) NOT NULL,
	[TechnologyName] [nvarchar](100) NOT NULL,
	[TechnologyInitial] [nvarchar](100) NOT NULL,
 CONSTRAINT [PK_Technology] PRIMARY KEY CLUSTERED 
(
	[TechnologyID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

