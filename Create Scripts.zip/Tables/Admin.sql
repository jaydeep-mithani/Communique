USE [Communique]
GO

/****** Object:  Table [dbo].[Admin]    Script Date: 02/20/20 10:22:10 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Admin](
	[AdminUsername] [nvarchar](50) NOT NULL,
	[AdminPassword] [nvarchar](50) NOT NULL
) ON [PRIMARY]
GO

