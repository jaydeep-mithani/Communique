USE [Communique]
GO

/****** Object:  Table [dbo].[Faculty]    Script Date: 02/20/20 10:23:40 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Faculty](
	[FacultyEmail] [nvarchar](100) NOT NULL,
	[FacultyFirstname] [nvarchar](100) NOT NULL,
	[FacultyLastname] [nvarchar](100) NOT NULL,
	[FacultyTechleader] [nvarchar](100) NOT NULL,
	[FacultyPassword] [nvarchar](100) NOT NULL,
 CONSTRAINT [PK_Faculty] PRIMARY KEY CLUSTERED 
(
	[FacultyEmail] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

